module Main where

type Var = String 
type Stuff = String 
data Statement = Lekha Stuff | Huncha Stuff Stuff | Jaba Var Code | Mukhya Code | Bhayo | Kaam Code | Jodi Int Int deriving (Eq, Show)
type Code = [Statement]

main :: IO ()
main = putStrLn "Hello, Haskell!"

-- Parser -> String -> Code
-- Code gen -> Code -> String (output.c)
